document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.sync.get(["whatsapp", "emospace"], res => {
    document.getElementById("whatsapp").checked = res.whatsapp !== false;
    document.getElementById("emospace").checked = res.emospace !== false;
  });
  
  document.getElementById("save").onclick = () => {
    chrome.storage.sync.set({
      whatsapp: document.getElementById("whatsapp").checked,
      emospace: document.getElementById("emospace").checked
    }, () => {
      document.getElementById("status").textContent = "Settings saved!";
    });
  };
});

