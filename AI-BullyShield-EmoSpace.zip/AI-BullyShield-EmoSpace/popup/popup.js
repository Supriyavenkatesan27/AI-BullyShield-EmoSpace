document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("toggle");
  const status = document.getElementById("status");
  
  chrome.storage.sync.get(["enabled"], res => {
    toggle.checked = res.enabled !== false;
  });
  
  toggle.onchange = () => {
    chrome.storage.sync.set({ enabled: toggle.checked }, () => {
      status.textContent = toggle.checked ? "Protection ON" : "Protection OFF";
      setTimeout(() => status.textContent = "", 2000);
    });
  };
});

