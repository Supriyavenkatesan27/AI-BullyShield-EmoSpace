console.log("🚀 BullyShield content script started");

const seenMessages = new Set();
let alertActive = false; // NEW: Prevent multiple alerts

function collectMessages() {
  const results = [];
  document.querySelectorAll("span").forEach(el => {
    const txt = (el.textContent || "").trim();
    if (txt.length > 3 && !seenMessages.has(txt)) {
      seenMessages.add(txt);
      results.push(txt);
    }
  });
  return results;
}

function showAlert(message, analysis) {
  // Remove any existing alert
  const existing = document.getElementById("bullyshield-alert");
  if (existing) existing.remove();
  
  alertActive = true; // Block new alerts
  
  const box = document.createElement("div");
  box.id = "bullyshield-alert";
  box.style.cssText = `
    position:fixed;top:20px;right:20px;max-width:340px;
    background:#f8d7da;color:#721c24;border:2px solid #dc3545;
    border-radius:12px;padding:20px;z-index:2147483647;
    font-family:Arial,sans-serif;box-shadow:0 8px 24px rgba(220,53,69,0.3);
  `;
  
  box.innerHTML = `
    <div style="font-weight:700;font-size:16px;margin-bottom:12px;display:flex;align-items:center;">
      🚨 <span style="margin-left:8px;">AI BullyShield × EmoSpace</span>
    </div>
    <div style="font-size:14px;margin-bottom:12px;background:#ffffffcc;padding:12px;border-radius:8px;">
      "${message}"
    </div>
    <div style="font-size:13px;margin-bottom:8px;">
      <span style="color:#d68910;">Type:</span> <b>${analysis.type}</b> 
      <span style="color:#27ae60;margin-left:16px;">Emotion:</span> <b>${analysis.emotion}</b>
    </div>
    <div style="display:flex;gap:12px;">
      <button id="report" style="flex:1;background:#dc3545;color:white;border:none;padding:10px;border-radius:8px;cursor:pointer;font-weight:600;">📤 Report</button>
      <button id="dismiss" style="flex:1;background:#6c757d;color:white;border:none;padding:10px;border-radius:8px;cursor:pointer;font-weight:600;">✖ Dismiss</button>
    </div>
  `;
  
  document.body.appendChild(box);
  
  document.getElementById("report").onclick = () => {
    chrome.runtime.sendMessage({type:"REPORT_BULLYING", message});
    document.getElementById("report").innerHTML = "✅ Reported to Firebase";
    document.getElementById("report").style.background = "#28a745";
  };
  
  document.getElementById("dismiss").onclick = () => {
    box.remove();
    alertActive = false; // Allow new alerts
  };
}

function scan() {
  if (alertActive) return; // NEW: Skip if alert showing
  
  chrome.storage.sync.get(["enabled"], cfg => {
    if (cfg.enabled === false) return;
    
    const msgs = collectMessages();
    console.log("Found messages:", msgs.length);
    
    msgs.forEach(msg => {
      if (typeof window.analyzeMessageLocal === "function") {
        const analysis = window.analyzeMessageLocal(msg);
        console.log("Analysis:", analysis);
        if (analysis.isHarmful) {
          showAlert(msg, analysis);
        }
      }
    });
  });
}

setInterval(scan, 2000);
console.log("✅ BullyShield scanning...");

