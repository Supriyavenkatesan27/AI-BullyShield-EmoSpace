chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ enabled: true });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "REPORT_BULLYING") {
    console.log("🚨 BullyShield Report:", request);
    sendResponse({ success: true });
  }
});




