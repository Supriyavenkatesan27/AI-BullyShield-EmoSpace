console.log("✅ BullyShield analyzer loaded");

const DICTIONARY = {
  en: { 
    verbal_bullying: ["useless", "stupid", "idiot", "loser", "bitch", "fuck", "fucking", "asshole", "nobody likes you"],
    threats: ["kill you", "die", "hurt you"],
    body_shaming: ["fat", "ugly"]
  },
  ta: { verbal_bullying: ["nee useless", "nee loosu", "poda", "loose"] },
  hi: { verbal_bullying: ["tu bekaar hai", "tum bewakoof ho", "harami"] }
};

function detectLanguage(text) {
  const t = text.toLowerCase();
  if (/(nee|poda)/.test(t)) return "ta";
  if (/(tu|tum|harami)/.test(t)) return "hi";
  return "en";
}

window.analyzeMessageLocal = function(message) {
  const text = message.toLowerCase();
  const lang = detectLanguage(text);
  const dict = DICTIONARY[lang] || DICTIONARY.en;
  
  let type = "none";
  if (dict.verbal_bullying.some(word => text.includes(word))) type = "verbal_bullying";
  else if (dict.threats?.some(word => text.includes(word))) type = "threat";
  else if (dict.body_shaming?.some(word => text.includes(word))) type = "body_shaming";
  
  const emotions = {
    "verbal_bullying": "hurt 😢",
    "threat": "scared 😨", 
    "body_shaming": "ashamed 😞",
    "none": "neutral 😊"
  };
  
  return {
    isHarmful: type !== "none",
    type,
    emotion: emotions[type] || "neutral",
    language: lang,
    safeReply: type === "none" ? "" : "This hurts my feelings. Please be kind."
  };
};




