# AI BullyShield powered by EmoSpace

A Chrome extension that detects cyberbullying in real time and provides emotional support using Google Gemini and Firebase.

## 🎯 Features

- Real-time message monitoring on WhatsApp, Instagram, Facebook, Google Meet, Classroom
- AI-powered bullying detection (verbal, threats, body shaming, self-harm)
- Emotion-aware UI (EmoSpace) for student mental well-being
- Anonymous reporting to counselors via Firebase
- Multi-platform, multilingual support

## 🛠 Tech Stack

- Google Gemini API (toxicity & emotion analysis)
- Firebase (Auth, Firestore, Hosting)
- Chrome Extension (Manifest V3)
- JavaScript, HTML, CSS

## 🚀 How to Run

1. Create a Firebase project and get `firebaseConfig`
2. Replace `YOUR_*` values in `firebase/firebase-config.js`
3. Load unpacked extension in Chrome:
   - `chrome://extensions` → Enable Developer mode
   - "Load unpacked" → Select this folder
4. Open popup, enter your Gemini API key, and enable the extension

## 🏆 Hackathon Ready

- Clean, modular code
- Professional UI/UX
- Full-cycle solution: Detection + Emotional Support
- Uses Google technologies meaningfully (Gemini + Firebase)

Team: Second Sense
