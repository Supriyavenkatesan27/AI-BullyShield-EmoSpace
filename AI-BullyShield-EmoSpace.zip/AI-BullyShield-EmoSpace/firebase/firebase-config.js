window.firebaseConfig = {
  apiKey: "demo-api-key",
  authDomain: "bullyshield-demo.firebaseapp.com",
  projectId: "bullyshield-demo"
};


