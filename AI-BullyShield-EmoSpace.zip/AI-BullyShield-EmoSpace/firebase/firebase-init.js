console.log("Firebase ready for reports (demo mode)");


